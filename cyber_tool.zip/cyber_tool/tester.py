import os
import sys
import time
import socket
import platform
import hashlib
import subprocess
import base64
from datetime import datetime

try:
    import requests
    import psutil
except ImportError:
    print("Error: Install required libraries using 'pip install requests psutil'")
    sys.exit()

# Enable colors on Windows 10/11
if os.name == 'nt':
    os.system('')

# Cyberpunk Palette (Dominant Magenta and Green)
GREEN = '\033[92m'
MAGENTA = '\033[95m'
CYAN = '\033[96m'
RED = '\033[91m'
YELLOW = '\033[93m'
RESET = '\033[0m'

HEADERS = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def boot_sequence():
    clear_screen()
    logo = f"""{MAGENTA}
   ______      __               ______           __ 
  / ____/_  __/ /_  ___  ____  /_  __/___  ____ / / 
 / /   / / / / __ \\/ _ \\/ ___/  / / / __ \\/ __ \\/ /  
/ /___/ /_/ / /_/ /  __/ /     / / / /_/ / /_/ / /  
\\____/\\__, /_.___/\\___/_/     /_/  \\____/\\____/_/   
     /____/                                         
    {RESET}"""
    print(logo)
    print(f"{GREEN}          >>> MADE BY APOX <<<{RESET}\n")
    print(f"{MAGENTA}[*] Injecting payload...{RESET}")
    time.sleep(0.4)
    print(f"{MAGENTA}[*] Bypassing security protocols...{RESET}")
    time.sleep(0.6)
    print(f"{GREEN}[+] ROOT access granted.{RESET}\n")
    time.sleep(1)

def web_stress_test():
    clear_screen()
    print(f"{MAGENTA}=== WEB STRESS TESTER (BENCHMARK) ==={RESET}")
    target = input(f"{GREEN}Enter URL to test (e.g., https://google.com): {RESET}").strip()
    if not target.startswith("http"): target = "https://" + target
    
    try:
        cicli = int(input(f"{GREEN}How many packets to send? (Max 50 recommended): {RESET}"))
    except ValueError:
        cicli = 10

    print(f"\n[{MAGENTA}*{RESET}] Starting load test on {target}...")
    tempi = []
    
    for i in range(cicli):
        try:
            start = time.time()
            res = requests.get(target, headers=HEADERS, timeout=5)
            ping = (time.time() - start) * 1000
            tempi.append(ping)
            if res.status_code == 200:
                print(f"[{GREEN}+{RESET}] Packet {i+1}/{cicli} | Response: {round(ping, 2)}ms")
            else:
                print(f"[{YELLOW}!{RESET}] Packet {i+1}/{cicli} | Status: {res.status_code}")
        except:
             print(f"[{RED}-{RESET}] Packet {i+1}/{cicli} | TIMEOUT (Server struggling to respond)")
    
    if tempi:
        avg = sum(tempi) / len(tempi)
        print(f"\n{MAGENTA}--- STRESS TEST RESULTS ---{RESET}")
        print(f"Average response time: {GREEN}{round(avg, 2)}ms{RESET}")
        if avg > 1000:
            print(f"[{RED}!{RESET}] The server is very slow, potential vulnerability to high load.")
        else:
             print(f"[{GREEN}+{RESET}] The server handled the load well.")

    input(f"\n{MAGENTA}Press ENTER to return to menu...{RESET}")

def wifi_vault_extractor():
    clear_screen()
    print(f"{MAGENTA}=== LOCAL WIFI VAULT EXTRACTOR ==={RESET}")
    if os.name != 'nt':
        print(f"[{RED}-{RESET}] This function is only available on Windows.")
        input(f"\n{MAGENTA}Press ENTER to return to menu...{RESET}")
        return
        
    print(f"[{MAGENTA}*{RESET}] Extracting system WPA/WPA2 keys...\n")
    time.sleep(1)
    
    try:
        profiles_data = subprocess.check_output(['netsh', 'wlan', 'show', 'profiles']).decode('utf-8', errors='ignore').split('\n')
        profiles = [line.split(':')[1].strip() for line in profiles_data if "All User Profile" in line or "Tutti i profili utente" in line]
        
        if not profiles:
            print(f"[{YELLOW}i{RESET}] No saved Wi-Fi networks found on this PC.")
        
        for profile in profiles:
            try:
                results = subprocess.check_output(['netsh', 'wlan', 'show', 'profile', profile, 'key=clear']).decode('utf-8', errors='ignore').split('\n')
                passwords = [line.split(':')[1].strip() for line in results if "Key Content" in line or "Contenuto chiave" in line]
                
                if passwords:
                    print(f"[{GREEN}+{RESET}] Network: {MAGENTA}{profile:<20}{RESET} | Password: {GREEN}{passwords[0]}{RESET}")
                else:
                     print(f"[{YELLOW}-{RESET}] Network: {MAGENTA}{profile:<20}{RESET} | Password: [EMPTY OR UNSAVED]")
            except subprocess.CalledProcessError:
                print(f"[{RED}!{RESET}] Read error for network {profile}")
                
    except Exception as e:
        print(f"[{RED}-{RESET}] Unable to access WLAN module: {e}")

    print(f"\n{YELLOW}[WARNING] Use this data responsibly.{RESET}")
    input(f"\n{MAGENTA}Press ENTER to return to menu...{RESET}")

def dns_interceptor():
    clear_screen()
    print(f"{MAGENTA}=== DNS INTERCEPTOR ==={RESET}")
    domain = input(f"{GREEN}Enter domain (e.g., microsoft.com): {RESET}").strip()
    domain = domain.replace("https://", "").replace("http://", "").split('/')[0]
    
    print(f"\n[{MAGENTA}*{RESET}] Tracing DNS records for {domain}...")
    try:
        if os.name == 'nt':
             result = subprocess.check_output(['nslookup', '-type=any', domain]).decode('utf-8', errors='ignore')
        else:
             result = subprocess.check_output(['host', '-a', domain]).decode('utf-8', errors='ignore')
             
        print(f"\n{GREEN}{result}{RESET}")
    except Exception:
         print(f"[{RED}-{RESET}] DNS command not supported on your terminal or domain does not exist.")
         
    input(f"\n{MAGENTA}Press ENTER to return to menu...{RESET}")

def cyber_cipher():
    clear_screen()
    print(f"{MAGENTA}=== CYBER CIPHER (BASE64) ==={RESET}")
    print(f"{GREEN}1.{RESET} Encrypt Message")
    print(f"{GREEN}2.{RESET} Decrypt Message")
    scelta = input(f"\n{MAGENTA}Select (1/2): {RESET}")
    
    if scelta == '1':
        msg = input(f"{GREEN}Message to hide: {RESET}")
        encoded = base64.b64encode(msg.encode('utf-8')).decode('utf-8')
        print(f"\n[{GREEN}+{RESET}] Encrypted Text: {MAGENTA}{encoded}{RESET}")
    elif scelta == '2':
        msg = input(f"{GREEN}Base64 code to decrypt: {RESET}")
        try:
            decoded = base64.b64decode(msg.encode('utf-8')).decode('utf-8')
            print(f"\n[{GREEN}+{RESET}] Clear Text: {GREEN}{decoded}{RESET}")
        except:
            print(f"[{RED}-{RESET}] Invalid string. Not valid Base64.")
            
    input(f"\n{MAGENTA}Press ENTER to return to menu...{RESET}")

def port_scanner():
    clear_screen()
    print(f"{MAGENTA}=== STEALTH PORT SCANNER ==={RESET}")
    print(f"{YELLOW}WARNING: Use this tool only on your own servers/routers.{RESET}")
    target = input(f"{GREEN}Enter IP or Domain to scan (e.g., 192.168.1.1): {RESET}").strip()
    
    ports = {21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS", 80: "HTTP", 443: "HTTPS", 3306: "MySQL", 3389: "RDP"}
    
    try:
        ip = socket.gethostbyname(target)
        print(f"\n[{MAGENTA}*{RESET}] Port scan on {ip} started at {datetime.now().strftime('%H:%M:%S')}")
        
        open_ports = 0
        for port, service in ports.items():
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(0.5)
            result = sock.connect_ex((ip, port))
            if result == 0:
                print(f"[{GREEN}+{RESET}] Port {port} OPEN ({service})")
                open_ports += 1
            sock.close()
            
        if open_ports == 0:
             print(f"[{YELLOW}i{RESET}] None of the common scanned ports appear to be open.")
    except socket.gaierror:
         print(f"[{RED}-{RESET}] Invalid hostname.")
         
    input(f"\n{MAGENTA}Press ENTER to return to menu...{RESET}")

def main_menu():
    boot_sequence()
    while True:
        clear_screen()
        print(f"{MAGENTA}============================================={RESET}")
        print(f"{GREEN}         CYBER TOOL - MADE BY APOX           {RESET}")
        print(f"{MAGENTA}============================================={RESET}")
        print(f"{MAGENTA}1.{RESET} {GREEN}Web Stress Tester{RESET}  (Load Benchmark)")
        print(f"{MAGENTA}2.{RESET} {GREEN}WiFi Extractor{RESET}     (Extracts local passwords)")
        print(f"{MAGENTA}3.{RESET} {GREEN}DNS Interceptor{RESET}    (Search server records)")
        print(f"{MAGENTA}4.{RESET} {GREEN}Cyber Cipher{RESET}       (Encrypt/Decrypt Base64)")
        print(f"{MAGENTA}5.{RESET} {GREEN}Port Scanner{RESET}       (Scan vulnerabilities)")
        print(f"{MAGENTA}0.{RESET} {RED}Self-Destruct (Exit){RESET}")
        print(f"{MAGENTA}============================================={RESET}")
        
        scelta = input(f"\n{GREEN}apox@cyber:~# {RESET}").strip()
        
        if scelta == '1': web_stress_test()
        elif scelta == '2': wifi_vault_extractor()
        elif scelta == '3': dns_interceptor()
        elif scelta == '4': cyber_cipher()
        elif scelta == '5': port_scanner()
        elif scelta == '0':
            print(f"\n{RED}Deleting system logs...{RESET}")
            time.sleep(0.5)
            print(f"{GREEN}Tracks erased. System offline.{RESET}")
            sys.exit()
        else:
            print(f"[{RED}!{RESET}] Command not recognized.")
            time.sleep(1)

if __name__ == "__main__":
    try:
        main_menu()
    except KeyboardInterrupt:
        print(f"\n\n{RED}[!] Forced override detected. Exiting.{RESET}")
        sys.exit()
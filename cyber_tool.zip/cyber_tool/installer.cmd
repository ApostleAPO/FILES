@echo off
title Cybex Tool - Auto Installer by apox
color 0A

echo ===================================================
echo       INITIALIZING CYBEX ENVIRONMENT...
echo ===================================================
echo.
echo [*] Controllo presenza Python nel sistema...
python --version >nul 2>&1

IF %ERRORLEVEL% NEQ 0 (
    echo [!] ERRORE: Python non e' installato!
    echo [*] Tentativo di installazione automatica in corso...
    winget install Python.Python.3.11 --silent
    IF %ERRORLEVEL% NEQ 0 (
        echo [!] L'installazione automatica e' fallita. 
        echo [!] Per favore, apri il Microsoft Store, cerca "Python" e installalo.
        pause
        exit
    )
    echo [+] Python installato! Riavvia questo script per continuare.
    pause
    exit
)

echo [+] Python rilevato con successo!
echo.
echo [*] Download e installazione dei moduli di Rete e Sistema...
pip install requests psutil
echo.
echo [+] Moduli pronti! 
echo.
echo [*] Avvio di CYBEX TOOL in corso...
timeout /t 3 >nul
cls
python cybex.py
pause
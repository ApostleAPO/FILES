import java.util.*;
//(classe Entita) che implementa l'interfaccia nameable
class Entita implements Nameable {
    private String nomeEntita;
    private double puntiVita;

    public Entita(String nomeEntita, double puntiVita) {
        this.nomeEntita = nomeEntita;
        this.puntiVita = puntiVita;
    }

    @Override
    public String getNome() {
        return nomeEntita;
    }

    public double getPuntiVita() {
        return puntiVita;
    }

    public void setPuntiVita(double puntiVita) {
        this.puntiVita = puntiVita;
    }
}

import java.util.*;
//(classe Arma) che eredita attributi da Item
class Arma extends Item {
    private int dado;
    private int modificatore;

    public Arma(String nomeArma, int dado, int modificatore) {
        super(nomeArma);
        this.dado = dado;
        this.modificatore = modificatore;
    }

    public double calcolaDanno() {
        double randomDanno = Math.random() * dado + 1;
        return randomDanno + modificatore;
    }
}

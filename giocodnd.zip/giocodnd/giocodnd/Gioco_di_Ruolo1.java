import java.util.*;

//(classe Gioco_di_Ruolo1)
public class Gioco_di_Ruolo1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Personaggio giocatore = new Personaggio("Shadow", 80);
        Mostro nemico = new Mostro("Partuix", 15);

        System.out.println("Nome del mostro: " + nemico.getNome() + ", Punti vita: " + (int) nemico.getPuntiVita());
        System.out.println("Nome del personaggio: " + giocatore.getNome() + ", Punti vita: " + (int) giocatore.getPuntiVita());

        do {
            System.out.println("\nVuoi combattere?");
            System.out.println("1. Sì");
            System.out.println("2. Visualizza inventario");
            System.out.println("3. Usa una pozione");
            System.out.println("4. Equipaggia un'arma");
            System.out.println("5. Esci dal gioco");
            int vitaNemico = (int) nemico.getPuntiVita();
            int scelta = scanner.nextInt();
            switch (scelta) {

                case 1:
             
             do {
                    double dannoInflitto = giocatore.attacca();
                    nemico.infliggiDanni(dannoInflitto);
                int danni = (int) dannoInflitto;
                vitaNemico=vitaNemico-danni;
                System.out.println(giocatore.getNome() + " attacca il nemico: " + nemico.getNome() + " infliggendogli " + danni + " danni.");
                System.out.println("Punti di vita rimasti al nemico (" + nemico.getNome() + "): " + vitaNemico);
            if (vitaNemico <= 0) {
                 System.out.println("Il nemico è stato sconfitto!");
                 giocatore.aggiungiItemAllInventario(new PozioneVita("Pozione", 6));
                 giocatore.aggiungiItemAllInventario(new Arma("Spada", 6, 2));
                    System.out.println("Hai trovato una pozione e un'arma nel bottino!");
                    break; 
                 }
                 } while (true); 
    break;


                case 2:
                    System.out.println("Inventario di " + giocatore.getNome() + ": ");
                    for (Item item : giocatore.getInventario()) {
                        System.out.println("- " + item.getNome());
                    }
                    break;
                case 3:
                    giocatore.usaPozione(new PozioneVita("Pozione", 6));
                    System.out.println(giocatore.getNome() + " ha utilizzato una pozione e ora ha " + (int) giocatore.getPuntiVita() + " punti vita.");
                    break;
                case 4:
                    giocatore.equipaggiaArma(new Arma("Spada", 6, 2));
                    System.out.println(giocatore.getNome() + " ha equipaggiato una spada.");
                    break;
                case 5:
                    System.out.println("Grazie per aver giocato!");
                    return;
            }
        } while (true);
    }
}

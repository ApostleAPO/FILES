import java.util.*;
//(classe Mostro) che eredita attributi da Entita
class Mostro extends Entita {
    private double puntiDanni;

    public Mostro(String nomeEntita, double puntiVita) {
        super(nomeEntita, puntiVita);
    }

    public void infliggiDanni(double danni) {
        puntiDanni += danni;
    }
}


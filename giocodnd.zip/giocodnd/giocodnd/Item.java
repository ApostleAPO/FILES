import java.util.*;
//(classe Item) che implementa l'interfaccia Nameable
class Item implements Nameable {
    private String itemName;

    public Item(String itemName) {
        this.itemName = itemName;
    }

    @Override
    public String getNome() {
        return itemName;
    }
}


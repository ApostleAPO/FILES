import java.util.*;
//(interfaccia nameable)
interface Nameable {
    String getNome();
}

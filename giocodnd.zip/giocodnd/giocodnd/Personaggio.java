import java.util.*;
//(classe Personaggio) che eredita attributi da Entita
class Personaggio extends Entita {
    private Vector<Item> inventario;
    private Arma armaEquipaggiata;

    public Personaggio(String nomeEntita, double puntiVita) {
        super(nomeEntita, puntiVita);
        this.inventario = new Vector<>();
    }

    public void aggiungiItemAllInventario(Item item) {
        inventario.add(item);
    }

    public void equipaggiaArma(Arma arma) {
        armaEquipaggiata = arma;
    }

    public double attacca() {
        double danno = 0;
        if (armaEquipaggiata != null) {
            danno = armaEquipaggiata.calcolaDanno();
        } else {
            danno = Math.random() * 4 + 1; // Attacco con le mani
        }
        return danno;
    }

    public void usaPozione(PozioneVita pozione) {
        double cura = pozione.usaPozione();
        double vitaAttuale = getPuntiVita();
        setPuntiVita(vitaAttuale + cura);
    }

    public Vector<Item> getInventario() {
        return inventario;
    }
}

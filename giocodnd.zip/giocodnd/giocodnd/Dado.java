import java.util.*;
//(classe Dado) per lanciare i dadi
class Dado {
    public static int lancioDado(int facce) {
        return (int) (Math.random() * facce) + 1;
    }
}

import java.util.*;
//(classe PozioneVita) che eredita attributi da Item
class PozioneVita extends Item {
    private int dado;

    public PozioneVita(String nomePozione, int dado) {
        super(nomePozione);
        this.dado = dado;
    }

    public double usaPozione() {
        double randomCura = Math.random() * dado + 1;
        return randomCura;
    }
}

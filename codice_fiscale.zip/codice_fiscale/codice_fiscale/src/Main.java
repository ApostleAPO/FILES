import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    private static final Map<String, String> comuniCodici = new HashMap<>();

    public static void main(String[] args) {
        System.out.println("Inserisci il cognome:");
        Scanner scanIn = new Scanner(System.in);
        String cognome = scanIn.nextLine();

        System.out.println("Inserisci il nome:");
        String nome = scanIn.nextLine();

        System.out.println("Inserisci l'anno di nascita:");
        int anno = scanIn.nextInt();

        System.out.println("Inserisci il mese di nascita:");
        String mese = scanIn.next();

        System.out.println("Inserisci il giorno di nascita:");
        int giorno = scanIn.nextInt();

        System.out.println("Inserisci il sesso (M per maschio, F per femmina):");
        char sesso = scanIn.next().toUpperCase().charAt(0);

        System.out.println("Inserisci il comune di nascita:");
        System.out.println("Inserire il comune tutto in maiuscolo");
        String comune = scanIn.next();

        scanIn.close();

        inizializzaComuniCodici();

        System.out.println("Comune inserito: " + comune);

        String comuneCodice = getComuneCodice(comune);

        if (comuneCodice != null) {
            char letteraMese = calcolaLetteraMese(mese);
            char letteraControllo = calcolaLetteraControllo(cognome, nome, anno, letteraMese, giorno, sesso, comuneCodice);
            String codiceFiscale = calcolaCodiceFiscale(cognome, nome, anno, letteraMese, giorno, sesso, comuneCodice, letteraControllo);
            System.out.println("Il codice fiscale è: " + codiceFiscale);
        } else {
            System.out.println("Comune non trovato.");
        }
    }

    public static void inizializzaComuniCodici() {
        try {
            File file = new File("comuni.txt");
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split("\t");
                if (parts.length == 2) {
                    comuniCodici.put(parts[0], parts[1]);
                } else {
                    System.out.println("Errore nel formato della riga: " + line);
                }
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("File non trovato.");
            e.printStackTrace();
        }
    }

    public static String getComuneCodice(String comune) {
        return comuniCodici.get(comune);
    }

    public static char calcolaLetteraMese(String mese) {
        char lettera;
        switch (mese.toLowerCase()) {
            case "gennaio":
                lettera = 'A';
                break;
            case "febbraio":
                lettera = 'B';
                break;
            case "marzo":
                lettera = 'C';
                break;
            case "aprile":
                lettera = 'D';
                break;
            case "maggio":
                lettera = 'E';
                break;
            case "giugno":
                lettera = 'F';
                break;
            case "luglio":
                lettera = 'G';
                break;
            case "agosto":
                lettera = 'H';
                break;
            case "settembre":
                lettera = 'L';
                break;
            case "ottobre":
                lettera = 'M';
                break;
            case "novembre":
                lettera = 'N';
                break;
            case "dicembre":
                lettera = 'P';
                break;
            default:
                throw new IllegalArgumentException("Mese non valido: " + mese);
        }
        return lettera;
    }

    public static char calcolaLetteraControllo(String cognome, String nome, int anno, char letteraMese, int giorno, char sesso, String comune) {
        String codiceFiscaleParziale = getCodiceCognome(cognome) + getCodiceNome(nome) + Integer.toString(anno).substring(2) + letteraMese + (giorno < 10 ? "0" + giorno : Integer.toString(giorno)) + sesso + comune;
        int sommaPari = 0;
        int sommaDispari = 0;

        for (int i = 0; i < codiceFiscaleParziale.length(); i++) {
            int valore = Character.getNumericValue(codiceFiscaleParziale.charAt(i));
            if ((i + 1) % 2 == 0) {
                sommaPari += valore;
            } else {
                sommaDispari += valore;
            }
        }

        int sommaTotale = sommaPari + sommaDispari;
        int resto = sommaTotale % 26;

        char letteraControllo;
        switch (resto) {
            case 0:
                letteraControllo = 'A';
                break;
            case 1:
                letteraControllo = 'B';
                break;
            case 2:
                letteraControllo = 'C';
                break;
            case 3:
                letteraControllo = 'D';
                break;
            case 4:
                letteraControllo = 'E';
                break;
            case 5:
                letteraControllo = 'F';
                break;
            case 6:
                letteraControllo = 'G';
                break;
            case 7:
                letteraControllo = 'H';
                break;
            case 8:
                letteraControllo = 'I';
                break;
            case 9:
                letteraControllo = 'J';
                break;
            case 10:
                letteraControllo = 'K';
                break;
            case 11:
                letteraControllo = 'L';
                break;
            case 12:
                letteraControllo = 'M';
                break;
            case 13:
                letteraControllo = 'N';
                break;
            case 14:
                letteraControllo = 'O';
                break;
            case 15:
                letteraControllo = 'P';
                break;
            case 16:
                letteraControllo = 'Q';
                break;
            case 17:
                letteraControllo = 'R';
                break;
            case 18:
                letteraControllo = 'S';
                break;
            case 19:
                letteraControllo = 'T';
                break;
            case 20:
                letteraControllo = 'U';
                break;
            case 21:
                letteraControllo = 'V';
                break;
            case 22:
                letteraControllo = 'W';
                break;
            case 23:
                letteraControllo = 'X';
                break;
            case 24:
                letteraControllo = 'Y';
                break;
            case 25:
                letteraControllo = 'Z';
                break;
            default:
                throw new IllegalArgumentException("Resto non valido: " + resto);
        }

        return letteraControllo;
    }

    public static String calcolaCodiceFiscale(String cognome, String nome, int anno, char letteraMese, int giorno, char sesso, String comune, char letteraControllo) {
        return getCodiceCognome(cognome) + getCodiceNome(nome) + Integer.toString(anno).substring(2) + letteraMese + (giorno < 10 ? "0" + giorno : Integer.toString(giorno)) + sesso + comune + letteraControllo;
    }

    public static String getCodiceCognome(String cognome) {
        StringBuilder codiceCognome = new StringBuilder();
        int consonantiAggiunte = 0;
        for (int i = 0; i < cognome.length(); i++) {
            char lettera = cognome.charAt(i);
            if (Character.isLetter(lettera) && !isVocale(lettera)) {
                codiceCognome.append(Character.toUpperCase(lettera));
                consonantiAggiunte++;
                if (consonantiAggiunte == 3) {
                    break;
                }
            }
        }
        while (consonantiAggiunte < 3) {
            for (int i = 0; i < cognome.length(); i++) {
                char lettera = cognome.charAt(i);
                if (Character.isLetter(lettera) && isVocale(lettera)) {
                    codiceCognome.append(Character.toUpperCase(lettera));
                    consonantiAggiunte++;
                    if (consonantiAggiunte == 3) {
                        break;
                    }
                }
            }
            if (consonantiAggiunte < 3) {
                codiceCognome.append('X');
                consonantiAggiunte++;
            }
        }
        return codiceCognome.toString();
    }

    public static String getCodiceNome(String nome) {
        StringBuilder codiceNome = new StringBuilder();
        int consonantiAggiunte = 0;
        for (int i = 0; i < nome.length(); i++) {
            char lettera = nome.charAt(i);
            if (Character.isLetter(lettera) && !isVocale(lettera)) {
                codiceNome.append(Character.toUpperCase(lettera));
                consonantiAggiunte++;
                if (consonantiAggiunte == 3) {
                    break;
                }
            }
        }
        while (consonantiAggiunte < 3) {
            for (int i = 0; i < nome.length(); i++) {
                char lettera = nome.charAt(i);
                if (Character.isLetter(lettera) && isVocale(lettera)) {
                    codiceNome.append(Character.toUpperCase(lettera));
                    consonantiAggiunte++;
                    if (consonantiAggiunte == 3) {
                        break;
                    }
                }
            }
            if (consonantiAggiunte < 3) {
                codiceNome.append('X');
                consonantiAggiunte++;
            }
        }
        return codiceNome.toString();
    }

    public static boolean isVocale(char lettera) {
        return "AEIOU".indexOf(Character.toUpperCase(lettera)) != -1;
    }
}

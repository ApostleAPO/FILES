import java.util.*;
/*
CONSEGNA:
Crea un programma per poter giocare alla torre di Hanoi.
Il programma in questione deve utilizzare le pile (Stack) e deve avere 3 torri e 3 dischi.
 Deve prendere l'input da tastiera, ad esempio scrivendo AB deve spostare il disco in cima da A in B. 
 Deve ovviamente controllare che le mosse siano legali e deve stampare un messaggio di "Vittoria" quando si sposta con successo tutta la colonna
 */

public class TorreDiHanoi {
    static Stack<Integer> A = new Stack<>();
    static Stack<Integer> B = new Stack<>();
    static Stack<Integer> C = new Stack<>();
    static int numDischi = 3;
    
    public static void main(String[] args) {
        for (int i = numDischi; i >= 1; i--) {
            A.push(i);
        }
        stampaTorri();
        while (!haiVinto()) {
            Scanner scanner = new Scanner(System.in);
            System.out.print("Inserisci il movimento che eseguirai (esempio da A a B..): ");
            String mossa = scanner.nextLine().toUpperCase();
            scanner.close();
            
            if (mossa.length() == 2 && "ABC".contains(mossa.substring(0, 1)) && "ABC".contains(mossa.substring(1))) {
                char da = mossa.charAt(0);
                char a = mossa.charAt(1);
                muovi(da, a);
            } else {
                System.out.println("Movimento non valido...Riprova!");
            }
            stampaTorri();
        }

        System.out.println("Congratulazioni ! Hai vinto il gioco!");
    }

    static void muovi(char da, char a) {
        Stack<Integer> torreX = torreAttuale(da);
        Stack<Integer> torreY = torreAttuale(a);
        
        if (!torreX.isEmpty() && (torreY.isEmpty() || torreY.peek() > torreX.peek())) {
            torreY.push(torreX.pop());
        } else {
            System.out.println("Movimento non valido...Riprova!");
        }
    }

    static Stack<Integer> torreAttuale(char c) {
        if (c == 'A') {
            return A;
        } else if (c == 'B') {
            return B;
        } else {
            return C;
        }
    }
    
    static boolean haiVinto() {
        return B.size() == numDischi || C.size() == numDischi;
    }

    static void stampaTorri() {
        System.out.println("TORRE A: " + A);
        System.out.println("TORRE B: " + B);
        System.out.println("TORRE C: " + C);
        System.out.println();
    }
}